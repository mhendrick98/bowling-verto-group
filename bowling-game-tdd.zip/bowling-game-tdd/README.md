## Bowling Game TDD Example

A simple exercise to learn TDD.
